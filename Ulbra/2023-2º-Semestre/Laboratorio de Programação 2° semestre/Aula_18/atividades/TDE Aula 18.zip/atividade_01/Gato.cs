class Gato : Animal{
    public override string EmitirSom(){
        return $"O {nome} esta miando";
    }
}