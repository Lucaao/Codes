class Cachorro : Animal{
    public override string EmitirSom(){
        return $"O {nome} esta latindo!";
    }
}