class Quadrado {
    public int Numero;
    public void CalcularEImprimirQuadrado(){
        int resultado = Numero * Numero;
        Console.WriteLine($"O resultado é {resultado}.");
    }
}