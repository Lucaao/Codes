﻿/* Exercício 2: Classe Quadrado
Classe: Quadrado
Atributos: numero
Método: CalcularEImprimirQuadrado()
Descrição: Crie um método que imprima o quadrado do número armazenado no atributo numero */

Quadrado quadrado = new Quadrado ();
quadrado.Numero = 10;
quadrado.CalcularEImprimirQuadrado();