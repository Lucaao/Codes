class CalculadoraSimples {
    public int Somar(int a, int b){
        return a + b;
    }
    public int Somar (int a, int b, int c){
        return a + b + c;
    }
}