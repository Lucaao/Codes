﻿/* Exercício 6: Classe Data
Classe: Data
Atributos: dia, mes, ano
Método: ImprimirDataFormatada()
Descrição: Crie um método que imprima a data formatada armazenada nos atributos.*/

Data data1 = new Data();
data1.dia = 05;
data1.mes = 10;
data1.ano = 2023;
data1.ImprimirDataFormatada();

Data data2 = new Data();
data2.dia = 10;
data2.mes = 12;
data2.ano = 2023;
data2.ImprimirDataFormatada();

Data data3 = new Data();
data3.dia = 02;
data3.mes = 02;
data3.ano = 2002;
data3.ImprimirDataFormatada();