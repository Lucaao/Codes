class Data {
    public int dia;
    public int mes;
    public int ano;
    public void ImprimirDataFormatada(){
        Console.WriteLine($"A data de hoje é {dia}/{mes}/{ano}.");
    }
}