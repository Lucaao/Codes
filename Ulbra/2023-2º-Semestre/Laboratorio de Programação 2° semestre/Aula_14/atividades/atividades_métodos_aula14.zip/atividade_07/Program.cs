﻿/* Exercício 7: Classe CalculadoraArea
Classe: CalculadoraArea
Métodos: Sobrecargas do método CalcularArea()
Descrição: Crie sobrecargas do método CalcularArea() conforme especificado anteriormente. Não utilize atributos. */

CalculadoraArea area = new CalculadoraArea();
Console.WriteLine(area.CalcularArea(10, 5));
Console.WriteLine(area.CalcularArea(10.5 , 5.9));
Console.WriteLine(area.CalcularArea(100.0, 52.0));