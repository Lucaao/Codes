class CalculadoraArea {
    public int CalcularArea(int a, int b){
        return a * b;
    }
    public double CalcularArea(double a, double b){
        return a * b;
    }
    public float CalcularArea(float a, float b){
        return a * b;
    }
}