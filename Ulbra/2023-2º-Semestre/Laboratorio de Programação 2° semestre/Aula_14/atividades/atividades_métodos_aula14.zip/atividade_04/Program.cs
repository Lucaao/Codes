﻿/* Exercício 4: Classe Concatenador
Classe: Concatenador
Métodos: Sobrecargas do método Concatenar()
Descrição: Crie sobrecargas do método Concatenar como especificado previamente, sem utilizar atributos. */

Concatenador concatenar = new Concatenador ();
concatenar.Concatenar("Lucas", "19/05/2002");
concatenar.Concatenar("Lucas", "20/05/2002" , "Rua Bulhufas");