class Concatenador {
    public void Concatenar (string nome, string data){
        Console.WriteLine("O nome é " + nome + " e a data é " + data + ".");
    }
    public void Concatenar (string nome, string data, string endereco){
        Console.WriteLine("O nome é "+ nome + ", a data é " + data + " e o endereço " + endereco + ".");
    }
}