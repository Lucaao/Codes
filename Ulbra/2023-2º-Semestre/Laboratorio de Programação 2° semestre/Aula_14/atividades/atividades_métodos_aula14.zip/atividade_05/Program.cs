﻿/* Exercício 5: Classe ConversorTemperatura
Classe: ConversorTemperatura
Atributos: temperaturaCelsius
Método: ConverterParaFahrenheit()
Descrição: Crie um método que retorne a temperaturaCelsius convertida para Fahrenheit. */

ConversorTemperatura converter = new ConversorTemperatura();
converter.temperaturaCelsius = 25;
converter.ConverterParaFahrenheit();