class Mensagem {
    public void Exibir (){
        Console.WriteLine("Bem vindo ao C#");
    }
}