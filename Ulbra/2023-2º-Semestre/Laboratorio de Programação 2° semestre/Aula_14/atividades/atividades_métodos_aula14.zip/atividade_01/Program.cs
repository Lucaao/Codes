﻿/* Exercício 1: Classe Mensagem
Classe: Mensagem
Método: Exibir()
Descrição: Crie um método que imprima a mensagem “Bem-vindo ao C#” sem receber parâmetros e sem utilizar atributos. */ 

Mensagem mensagem = new Mensagem ();
mensagem.Exibir();