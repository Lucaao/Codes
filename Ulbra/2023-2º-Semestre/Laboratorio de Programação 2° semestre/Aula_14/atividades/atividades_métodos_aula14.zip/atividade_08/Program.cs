﻿/* Exercício 8: Classe Tabuada
Classe: Tabuada
Atributos: numeroBase
Método: ImprimirTabuada()
Descrição: Crie um método que imprima a tabuada do numeroBase. */

Tabuada tabuada10 = new Tabuada();
tabuada10.numeroBase = 10;
tabuada10.imprimirTabuada();

Tabuada tabuada9 = new Tabuada();
tabuada9.numeroBase = 9;
tabuada9.imprimirTabuada();