public abstract class Forma {
    public abstract void CalcularArea();
}