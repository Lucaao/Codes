public class Gato : Animal{
    public string? nome;
    public override void FazerSom(){
        Console.WriteLine($"O {nome} está miando, Miau Miau Miau");
    }
}