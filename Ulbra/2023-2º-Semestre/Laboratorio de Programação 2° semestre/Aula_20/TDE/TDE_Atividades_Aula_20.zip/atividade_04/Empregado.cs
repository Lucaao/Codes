public abstract class Empregado{
    public int salario = 1000;
    public abstract void CalcularSalário();
}