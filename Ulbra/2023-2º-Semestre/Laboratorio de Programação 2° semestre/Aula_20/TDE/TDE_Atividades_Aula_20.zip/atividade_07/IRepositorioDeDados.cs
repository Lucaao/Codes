public interface IRepositorioDeDados{
    void Salvar (string dados);
    string Carregar();
}