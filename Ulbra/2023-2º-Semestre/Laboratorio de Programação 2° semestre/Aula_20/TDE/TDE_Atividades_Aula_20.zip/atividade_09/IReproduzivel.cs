public interface IReproduzível{
    public void Reproduzir(string musica);
    public void Pausar(string musica);
    public void Parar(string musica);
}