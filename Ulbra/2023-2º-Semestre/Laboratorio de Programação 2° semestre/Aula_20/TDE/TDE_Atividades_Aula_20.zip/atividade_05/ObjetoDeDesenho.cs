public abstract class ObjetoDeDesenho {
    public abstract void Desenhar();
}