public class Circulo : ObjetoDeDesenho {
    public override void Desenhar(){
        Console.WriteLine("Desenhando um circulo! BIP BIP BOP BOP.");
    }
}