﻿/* Sistema de Desenho:
Defina uma classe abstrata ObjetoDeDesenho com um método abstrato Desenhar.
Implemente Desenhar em classes derivadas como Linha e Círculo. */

Linha L1 = new Linha();
L1.Desenhar();

Circulo C1 = new Circulo();
C1.Desenhar();