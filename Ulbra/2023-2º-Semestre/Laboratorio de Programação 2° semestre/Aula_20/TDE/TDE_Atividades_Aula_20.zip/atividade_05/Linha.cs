public class Linha : ObjetoDeDesenho {
    public override void Desenhar(){
        Console.WriteLine("Desenhando uma linha! BIP BIP BOP BOP.");
    }
}