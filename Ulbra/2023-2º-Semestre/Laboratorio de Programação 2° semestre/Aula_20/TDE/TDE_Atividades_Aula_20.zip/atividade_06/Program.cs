﻿/* Exercícios de Interfaces
Interface IMovível:
Crie uma interface IMovível com um método Mover.
Implemente IMovível em diferentes classes, como Animal, Veículo. */ 

Animal A1 = new Animal();
A1.Mover();

Veiculo V1 = new Veiculo();
V1.Mover();