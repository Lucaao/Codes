public class Animal : IMovivel{
    public void Mover(){
        Console.WriteLine("O animal está se movendo!");
    }
}