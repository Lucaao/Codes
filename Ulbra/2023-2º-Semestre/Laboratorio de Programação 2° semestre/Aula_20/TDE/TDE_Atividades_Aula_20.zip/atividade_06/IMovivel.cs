public interface IMovivel{
    void Mover();
}