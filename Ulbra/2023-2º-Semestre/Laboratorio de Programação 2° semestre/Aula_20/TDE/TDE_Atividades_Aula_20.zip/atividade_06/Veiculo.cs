public class Veiculo : IMovivel{
    public void Mover(){
        Console.WriteLine("O veiculo está se movendo!");
    }
}