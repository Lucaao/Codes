public interface ISensor{
    public void LerValor(double valor);
}