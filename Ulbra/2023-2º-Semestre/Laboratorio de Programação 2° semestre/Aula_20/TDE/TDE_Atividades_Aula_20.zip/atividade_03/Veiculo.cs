public abstract class Veiculo {
    public abstract void IniciarMotor();
}