﻿/* Sistema de Veículos:
Crie uma classe abstrata Veículo com um método abstrato IniciarMotor.
Derive classes como Carro e Motocicleta, implementando o método IniciarMotor. */

Carro c1 = new Carro("Chevette");
c1.IniciarMotor();

Motocicleta m1 = new Motocicleta ("Adelaide");
m1.IniciarMotor();