﻿/* Interface Imprimível:
Crie uma interface IImprimível com um método Imprimir.
Implemente IImprimível em diferentes classes, como Documento, Imagem. */

Documento DC1 = new Documento();
DC1.Imprimir();

Imagem IMG1 = new Imagem();
IMG1.Imprimir();