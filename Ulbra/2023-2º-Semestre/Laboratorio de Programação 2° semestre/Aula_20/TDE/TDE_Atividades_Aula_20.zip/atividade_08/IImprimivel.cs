public interface IImprimível{
    public void Imprimir();
}