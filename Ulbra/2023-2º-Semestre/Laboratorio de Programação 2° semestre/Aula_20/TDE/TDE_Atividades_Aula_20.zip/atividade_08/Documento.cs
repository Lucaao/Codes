public class Documento : IImprimível{
    public void Imprimir(){
        Console.WriteLine("O documento está sendo impresso!");
    }
}