public class Imagem : IImprimível{
    public void Imprimir(){
        Console.WriteLine("A imagem está sendo impressa!");
    }
}