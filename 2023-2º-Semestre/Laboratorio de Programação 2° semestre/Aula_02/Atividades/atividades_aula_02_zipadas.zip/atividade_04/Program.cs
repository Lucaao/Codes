﻿/* Atividade 4 */

string data = "04/09/1999";
Console.WriteLine(data);