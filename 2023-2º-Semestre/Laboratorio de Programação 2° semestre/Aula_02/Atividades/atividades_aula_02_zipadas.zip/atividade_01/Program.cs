﻿/* Atividade 1 */

int idade = 35;
Console.WriteLine(idade);