﻿/* Atividade 8 */

string cidade = "São Paulo";
Console.WriteLine(cidade);