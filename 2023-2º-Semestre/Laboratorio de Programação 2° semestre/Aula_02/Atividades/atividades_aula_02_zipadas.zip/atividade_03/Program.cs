﻿/* Atividade 3*/

double altura = 3.45;
Console.WriteLine(altura);