﻿/* Atividade 6 */

double? nota = 7.80;
Console.WriteLine(nota);