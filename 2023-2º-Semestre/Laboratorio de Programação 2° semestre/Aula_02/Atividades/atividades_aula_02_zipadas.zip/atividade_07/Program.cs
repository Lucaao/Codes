﻿/* Atividade 7 */

double peso = 68.5;
Console.WriteLine(peso);