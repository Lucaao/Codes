﻿/* Atividade 11 */

double? temperatura = 22.5;
Console.WriteLine(temperatura);