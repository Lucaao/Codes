﻿/* Atividade 5 */

const int ano = 12;
Console.WriteLine(ano);