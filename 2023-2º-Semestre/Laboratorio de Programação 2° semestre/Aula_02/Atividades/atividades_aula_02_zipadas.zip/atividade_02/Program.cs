﻿/* Atividade 2 */

string nome = "Maria";
Console.WriteLine(nome);