﻿/* Atividade 10 */

string nascimento = "10/12/1985";
Console.WriteLine(nascimento);